import sys
import os
import repl
import astext
import core.runner

version = "Alpha 2"
arg = sys.argv

try:
    if arg[1] == "-r" or arg[1] == "--repl":
        repl.repl()
    elif arg[1] == "-v" or arg[1] == "--version":
        print(version)
    elif arg[1] == "-h" or arg[1] == "--help":
        print("Commands list ~ \n" \
"-r --repl              Opens REPL\n" \
"-v --version           Tell the version of flex\n" \
"[FILE]                 Compiles the file\n" \
"-s [FILE]              Runs the .flexAbstractTree\n" \
"-l --learn             To learn flex\n" \
"-h --help              Open help\n" \
"-cu --checkforupdate   Checks for update for flex\n" \
"") 
    elif arg[1] == ("-l" or "--learn"):
        print("see learn.html you got with it")
    elif arg[1] == ("-cu" or "--checkforupdate"):
        print("Comming Soon, Update Manually")
    elif arg[1] == "-s":
        ast = astext.decode_tree(arg[2])
        #print("DECODED AST:", ast)  # Debug print
        runner = core.runner.Runner()
        runner.run_tree(ast)


    else:
        astext.execute(arg[1])
except IndexError: print("Commands list ~ \n" \
"-r --repl              Opens REPL\n" \
"-v --version           Tell the version of flex\n" \
"[FILE]                 Compiles the file\n" \
"-s [FILE]              Runs the .flexAbstractTree\n" \
"-l --learn             To learn flex\n" \
"-h --help              Open help\n" \
"-cu --checkforupdate   Checks for update for flex\n" \
"") 

except:print(":(")