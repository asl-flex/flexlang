import json
import re
filel = ""
def fetchdata(filea):
    global filel
    filel = filea
    with open(filea, "r") as file:
        return [line.strip() for line in file]
def tokenize_blocks(lines):
    blocks = []
    current_block = []
    depth = 0
    for line in lines:
        tokens = re.split(r'(\{|\})', line.strip())
        for token in tokens:
            token = token.strip()
            if not token:
                continue
            if token == '{':
                depth += 1
                current_block.append('{')
            elif token == '}':
                depth -= 1
                current_block.append('}')
                if depth == 0:
                    blocks.append(current_block)
                    current_block = []
            else:
                current_block.append(token)
    if current_block:
        blocks.append(current_block)
    return blocks
def parse_args(arg_str):
    args = []
    for arg in arg_str.split(','):
        arg = arg.strip().rstrip(';')
        if arg.isdigit():
            args.append(["int", int(arg)])
        elif re.match(r'^\d+\.\d+$', arg):
            args.append(["float", float(arg)])
        elif arg.startswith('"') and arg.endswith('"'):
            args.append(["string", arg.strip('"')])
        else:
            args.append(["varobject", arg])
    return args
def parse_block(lines):
    block = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "" or line.startswith("#"):
            block.append(["unknown", ""])
            i += 1
            continue
        if line.startswith("class "):
            class_name = line.split()[1].strip(":")
            class_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                class_body.extend(sub_block)
                i += 1
            block.append(["class_def", class_name, class_body])
            continue
        if line.startswith("fnx "):
            parts = line[4:].split("(")
            func_name = parts[0].strip()
            args = parts[1].rstrip("):").strip()
            arg_list = [a.strip() for a in args.split(",")] if args else []
            func_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                func_body.extend(sub_block)
                i += 1
            block.append(["function_def", func_name, ["fn_var"] + arg_list, func_body])
            continue
        if line.startswith("if "):
            condition = line[3:].strip().rstrip(":").strip("()")
            if_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                if_body.extend(sub_block)
                i += 1
            block.append(["if", "equation", condition, if_body])
            continue
        if line.startswith("else"):
            else_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                else_body.extend(sub_block)
                i += 1
            block.append(["block", else_body])
            continue
        block.append(parse_line(line))
        i += 1
    return block
def parse_line(line):
    line = line.strip()
    if line == "":
        return ["unknown", ""]
    if line.startswith("import-"):
        return ["import", line.split('"')[1]]
    if line.startswith("class "):
        return ["class_start", line.split()[1].strip(":")]
    if line.startswith("fnx "):
        parts = line[4:].split("(")
        name = parts[0].strip()
        args = parts[1].rstrip("):").strip()
        arg_list = [a.strip() for a in args.split(",")] if args else []
        return ["function_start", name, ["fn_var"] + arg_list]
    if "=" in line and not line.startswith("if") and not line.startswith("while") and not line.startswith("for"):
        name, val = line.split("=", 1)
        name = name.strip()
        val = val.strip().rstrip(";")
        if "." in val or "*" in val or "+" in val or "-" in val or "/" in val:
            return ["assign", name, ["objectvar_equation", val]]
        else:
            return ["assign", name, ["varobject", val]]
    if line.startswith("reg "):
        inside = line[4:].split(":")
        return ["register", inside[0].strip().strip('"'), int(inside[1])]
    if line.startswith("cell "):
        num, val = line[5:].split(":")
        return ["cell_assign", int(num.strip()), val.strip().strip('"')]
    if line.startswith("pointer("):
        return ["pointer_set", int(line[8:-2])]
    if line == "print(:/);":
        return ["cell_print"]
    if line.startswith("if "):
        condition = line[3:].strip().rstrip(":").strip("()")
        return ["if_start", "equation", condition]
    if line.startswith("else"):
        return ["else_start"]
    if line.startswith("lambda "):
        expr = line[7:].strip()
        return ["lambda", ["objectvar_equation", expr]]
    if line.startswith("return "):
        expr = line[7:].strip()
        return ["return", ["objectvar_equation", expr]]
    if "(" in line and line.endswith(");"):
        name = line.split("(")[0].strip()
        args = line[line.find("(")+1:line.rfind(")")].strip()
        arg_list = [a.strip() for a in args.split(",")] if args else []
        return ["FunctionCall", name, [["varobject", a] for a in arg_list]]
    if "." in line and "(" in line and line.endswith(");"):
        obj, rest = line.split(".", 1)
        method, args = rest[:-2].split("(", 1)
        arg_list = [a.strip() for a in args.split(",")] if args else []
        return ["dot_call", obj.strip(), method.strip(), [["varobject", a] for a in arg_list]]
    return ["unknown", line]
def ast_builder(lines):
    ast = []
    block_stack = []
    current_block = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.endswith("{"):
            current_block.append(line)
            block_stack.append("{")
            continue
        elif line == "}":
            current_block.append(line)
            if block_stack:
                block_stack.pop()
            if not block_stack:
                parsed = parse_block(current_block)
                if parsed:
                    ast.append(parsed)
                current_block = []
            continue
        if block_stack:
            current_block.append(line)
        else:
            parsed_line = parse_line(line)
            if parsed_line:
                ast.append(parsed_line)
    if current_block:
        parsed = parse_block(current_block)
        if parsed:
            ast.append(parsed)
    return ast
def extract_block(lines, start_index):
    block = []
    depth = 0
    i = start_index
    while i < len(lines):
        line = lines[i].strip()
        if '{' in line:
            depth += line.count('{')
        if '}' in line:
            depth -= line.count('}')
        block.append(line)
        if depth == 0:
            break
        i += 1
    return block, i
def execute(file):
    ast_tree = ast_builder(fetchdata(file))
    with open(filel + "AbstractTree", "w") as file:
        json.dump(ast_tree, file)
def decode_tree(path):
    with open(path, "r") as file:
        return json.load(file)