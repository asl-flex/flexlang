import re
from math import modf

class ArithmeticEvaluator:
    def __init__(self):
        self.operators = {
            '^': (4, lambda a, b: a ** b),
            '*': (3, lambda a, b: a * b),
            '/': (3, lambda a, b: a / b),
            '//': (3, lambda a, b: a // b),
            '%': (3, lambda a, b: a % b),
            '+': (2, lambda a, b: a + b),
            '-': (2, lambda a, b: a - b),
        }
    
    def evaluate(self, expression):
        try:
            expr = expression.replace(' ', '')
            if not expr:
                return [0, ["int", 0]]
            
            tokens = self._tokenize(expr)
            postfix = self._infix_to_postfix(tokens)
            result = self._evaluate_postfix(postfix)
            
            if isinstance(result, int):
                return [result, ["int", result]]
            else:
                fractional, whole = modf(result)
                return [
                    result,
                    ["float", result, int(whole), int(round(abs(fractional) * 100))]
                ]
        except Exception as e:
            raise ValueError(f"Evaluation error: {str(e)}")

    def _tokenize(self, expr):
        token_pattern = r'(\d+\.?\d*)|([+\-*/%^()])|(//)'
        tokens = []
        i = 0
        n = len(expr)
        
        while i < n:
            # Check for multi-character operators first
            if i+1 < n and expr[i:i+2] == '//':
                tokens.append('//')
                i += 2
                continue
            
            # Check for single-character operators
            if expr[i] in '+-*/%^()':
                tokens.append(expr[i])
                i += 1
                continue
            
            # Handle numbers
            if expr[i].isdigit() or expr[i] == '.':
                j = i
                while j < n and (expr[j].isdigit() or expr[j] == '.'):
                    j += 1
                num_str = expr[i:j]
                if '.' in num_str:
                    tokens.append(float(num_str))
                else:
                    tokens.append(int(num_str))
                i = j
                continue
            
            # If we get here, it's an invalid character
            raise ValueError(f"Invalid character: {expr[i]}")
        
        return tokens

    def _infix_to_postfix(self, tokens):
        output = []
        stack = []
        
        for token in tokens:
            if isinstance(token, (int, float)):
                output.append(token)
            elif token == '(':
                stack.append(token)
            elif token == ')':
                while stack and stack[-1] != '(':
                    output.append(stack.pop())
                if not stack:
                    raise ValueError("Mismatched parentheses")
                stack.pop()  # Remove the '('
            else:  # Operator
                while (stack and stack[-1] != '(' and
                       self.operators.get(stack[-1], (0,))[0] >= self.operators[token][0]):
                    output.append(stack.pop())
                stack.append(token)
        
        while stack:
            if stack[-1] == '(':
                raise ValueError("Mismatched parentheses")
            output.append(stack.pop())
        
        return output

    def _evaluate_postfix(self, postfix):
        stack = []
        
        for token in postfix:
            if isinstance(token, (int, float)):
                stack.append(token)
            else:
                if len(stack) < 2:
                    raise ValueError("Invalid expression")
                b = stack.pop()
                a = stack.pop()
                try:
                    result = self.operators[token][1](a, b)
                    stack.append(result)
                except ZeroDivisionError:
                    raise ValueError("Division by zero")
        
        if len(stack) != 1:
            raise ValueError("Invalid expression")
        
        return stack[0]


# Test function
def test_evaluator():
    evaluator = ArithmeticEvaluator()
    test_cases = [
        ("2+2", [4, ["int", 4]]),
        ("3.5*2", [7.0, ["float", 7.0, 7, 0]]),
        ("10/3", [3.3333333333333335, ["float", 3.3333333333333335, 3, 33]]),
        ("10//3", [3, ["int", 3]]),
        ("2^3", [8, ["int", 8]]),
        ("5%2", [1, ["int", 1]]),
        ("(1+2)*3", [9, ["int", 9]]),
    ]
    
    for expr, expected in test_cases:
        try:
            result = evaluator.evaluate(expr)
            assert result == expected, f"Test failed for {expr}. Expected {expected}, got {result}"
            print(f"✓ {expr} = {result}")
        except Exception as e:
            print(f"✗ {expr} failed: {str(e)}")

if __name__ == "__main__":
    test_evaluator()
    print("\nInteractive mode:")
    evaluator = ArithmeticEvaluator()
    while True:
        try:
            expr = input("> ").strip()
            if expr.lower() in ('exit', 'quit'):
                break
            result = evaluator.evaluate(expr)
            print(result)
        except Exception as e:
            print(f"Error: {str(e)}")