import json
from core.evaluator import ArithmeticEvaluator

class Runner:
    variables = {}

    @staticmethod
    def is_valid_literal(value):
        # Accept numbers, booleans, lists, and quoted strings only
        if value.startswith('"') and value.endswith('"'):
            return True
        if value.isdigit():
            return True
        if value in ['true', 'false']:
            return True
        if value.startswith('[') and value.endswith(']'):
            return True
        return False

    @staticmethod
    def run_tree(tree):
        for node in tree:
            Runner.run_node(node)

    @staticmethod
    def run_node(node):
        if not isinstance(node, list) or len(node) == 0:
            return

        node_type = node[0]

        if node_type == "FunctionCall":
            func_name = node[1]
            args = node[2]
            if func_name == "print":
                output = []
                for arg in args:
                    if arg[0] == "varobject":
                        value = arg[1]
                        if not Runner.is_valid_literal(value):
                            print(f"Error: Invalid literal '{value}'")
                            return
                        output.append(eval(value))
                    elif arg[0] == "objectvar_equation":
                        result = ArithmeticEvaluator.evaluate(arg[1])
                        output.append(result[0])
                    else:
                        output.append(f"[Unsupported arg type: {arg[0]}]")
                print(*output)

        elif node_type == "assign":
            var_name = node[1]
            value_node = node[2]
            if value_node[0] == "varobject":
                value = value_node[1]
                if Runner.is_valid_literal(value):
                    Runner.variables[var_name] = eval(value)
                else:
                    print(f"Error: Invalid assignment value '{value}'")
            elif value_node[0] == "objectvar_equation":
                result = ArithmeticEvaluator.evaluate(value_node[1])
                Runner.variables[var_name] = result[0]
