from core.evaluator import ArithmeticEvaluator
from astext import parse_line
import sys

# RAM memory store
memory = {}

def is_expression(text):
    try:
        # Simple test for math-only line
        evaluator = ArithmeticEvaluator()
        evaluator.evaluate(text)
        return True
    except:
        return False

def execute_flex_ast(ast):
    if ast[0] == "assign":
        varname = ast[1]
        value_expr = ast[2]
        if value_expr[0] == "varobject":
            value = eval(value_expr[1], {}, memory)  # Eval with memory context
        else:
            value = value_expr[1]
        memory[varname] = value
        print(f"{varname} = {value}")

    elif ast[0] == "FunctionCall":
        funcname = ast[1]
        args = ast[2]
        if funcname == "print":
            val = args[0][1]
            if val in memory:
                print(memory[val])
            else:
                print(val)
        elif funcname == "println":
            val = args[0][1]
            if val in memory:
                print(memory[val])
            else:
                print(val)

    elif ast[0] == "pointer":
        print(f"Pointer switched to cell {ast[1]} (mock)")
    elif ast[0] == "register":
        print(f"Register {ast[1]} set to {ast[2]}")
    else:
        print(f"Unknown AST command: {ast}")

def repl():
    evaluator = ArithmeticEvaluator()
    
    while True:
        try:
            get = input("FLEX ~ >").strip()
            if get.lower() in ('exit', 'quit'):
                break

            # If it's a math expression, evaluate
            if is_expression(get):
                result = evaluator.evaluate(get)
                print(result[0])
            else:
                # Try Flex command parsing
                ast = parse_line(get)
                if ast:
                    execute_flex_ast(ast)
                else:
                    print(":( Could not parse command")

        except Exception as e:
            print(f":( Internal Error - {str(e)}")

if __name__ == "__main__":
    repl()
