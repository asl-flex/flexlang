import sys
import os
import repl
import core.astext as astext
from core.runner import Runner

version = "FLEX BETA 11.05 CORE-COMPLETED"
arg = sys.argv

try:
    if arg[1] == "-r" or arg[1] == "--repl":
        repl.repl()

    elif arg[1] == "-v" or arg[1] == "--version":
        print(version)

    elif arg[1] == "-h" or arg[1] == "--help":
        print("Commands list ~ \n"
              "-r --repl              Opens REPL\n"
              "-v --version           Tell the version of flex\n"
              "[FILE]                 Compiles the file\n"
              "-s [FILE]              Runs the .flexAbstractTree\n"
              "-l --learn             To learn flex\n"
              "-h --help              Open help\n"
              "-cu --checkforupdate   Checks for update for flex\n")

    elif arg[1] == "-l" or arg[1] == "--learn":
        print("See learn.html you got with it")

    elif arg[1] == "-cu" or arg[1] == "--checkforupdate":
        print("Coming Soon, update manually")

    elif arg[1] == "-s":
        ast = astext.decode_tree(arg[2])
        runner = Runner()
        runner.run_tree(ast)

    else:
        astext.execute(arg[1])

except IndexError:
    print("Commands list ~ \n"
          "-r --repl              Opens REPL\n"
          "-v --version           Tell the version of flex\n"
          "[FILE]                 Compiles the file\n"
          "-s [FILE]              Runs the .flexAbstractTree\n"
          "-l --learn             To learn flex\n"
          "-h --help              Open help\n"
          "-cu --checkforupdate   Checks for update for flex\n")

except Exception as e:
    print("Unexpected error:", e)

