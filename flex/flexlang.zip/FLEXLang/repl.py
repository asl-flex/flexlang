from core.evaluator import ArithmeticEvaluator
from core.astext import parse_line
import sys

memory = {}

def is_expression(text):
    try:
        evaluator = ArithmeticEvaluator()
        evaluator.evaluate(text)
        return True
    except:
        return False

def execute_flex_ast(ast):
    if ast[0] == "assign":
        varname = ast[1]
        value_expr = ast[2]
        if value_expr[0] == "varobject":
            value = memory.get(value_expr[1])
            if value is None:
                print(f"Error: Variable '{value_expr[1]}' is not defined")
                return
        else:
            value = value_expr[1]
        memory[varname] = value
        print(f"{varname} = {value}")

    elif ast[0] == "FunctionCall":
        funcname = ast[1]
        args = ast[2]
        val = args[0][1]
        if funcname == "print":
            print(memory.get(val, val), end="")
        elif funcname == "println":
            print(memory.get(val, val))

    elif ast[0] == "pointer":
        print(f"Pointer switched to cell {ast[1]} (mock)")

    elif ast[0] == "register":
        print(f"Register {ast[1]} set to {ast[2]}")

    else:
        print(f"Unknown or unimplemented command: {ast[0]}")

def repl():
    evaluator = ArithmeticEvaluator()
    
    while True:
        try:
            get = input("FLEX ~ >").strip()
            if get.lower() in ('exit', 'quit'):
                break

            if is_expression(get):
                result = evaluator.evaluate(get)
                print(result[0])
            else:
                ast = parse_line(get)
                if ast:
                    execute_flex_ast(ast)
                else:
                    print(":( Could not parse command")

        except Exception as e:
            print(f":( Internal Error - {str(e)}")

if __name__ == "__main__":
    repl()

