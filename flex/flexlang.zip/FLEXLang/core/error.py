class ErrorHandler:
    @staticmethod
    def runtime_error(message):
        print(f"Runtime Error: {message}")

    @staticmethod
    def syntax_error(message):
        print(f"Syntax Error: {message}")

    @staticmethod
    def internal_error(message):
        print(f":( Internal Error - {message}")
