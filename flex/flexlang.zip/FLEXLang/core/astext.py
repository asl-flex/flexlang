import json
import re
filel = ""
import re
def parse_if_block(lines, i):
    block = ["if_block", []]
    while i < len(lines):
        line = lines[i].strip()

        if line.startswith("if (") and line.endswith(") {"):
            condition = line[3:line.find(")")+1].strip("()")
            i += 1
            body = []
            while i < len(lines) and lines[i].strip() != "}":
                stmt, i = parse_line(lines, i)
                body.append(stmt)
            block[1].append(["condition", condition, body])

        elif line.startswith("elif (") and line.endswith(") {"):
            condition = line[5:line.find(")")+1].strip("()")
            i += 1
            body = []
            while i < len(lines) and lines[i].strip() != "}":
                stmt, i = parse_line(lines, i)
                body.append(stmt)
            block[1].append(["elif", condition, body])

        elif line.startswith("else {"):
            i += 1
            body = []
            while i < len(lines) and lines[i].strip() != "}":
                stmt, i = parse_line(lines, i)
                body.append(stmt)
            block[1].append(["else", body])
            break

        else:
            break

        i += 1

    return block, i

def decode_flex_string(s):
    return (
        s.replace('"', 'XxXA')
         .replace("'", 'XxXB')
         .replace(",", 'XxXC')
         .replace("-", 'XxXD')
         .replace(":", 'XxXE')
    )
def split_arguments(text):
    """
    Splits a string by commas, but ignores commas inside double quotes.
    """
    pattern = r''',(?=(?:[^"]*"[^"]*")*[^"]*$)'''
    return [arg.strip() for arg in re.split(pattern, text)]

def is_equation(text):
    if text.startswith('"') and text.endswith('"'):
        return False  # It's just a string
    # Continue with actual equation logic


    stripped = text.strip()

    # Skip clearly quoted strings
    if (stripped.startswith('"') and stripped.endswith('"')) or \
       (stripped.startswith("'") and stripped.endswith("'")):
        return False
    elif stripped.startswith("if (") and stripped.endswith(") {"):
        return parse_if_block(lines, i)


    # Check for math operators
    math_operators = set("+-*/%^=()")
    has_operator = any(op in stripped for op in math_operators)

    # If it's just a variable name or number, not equation
    if stripped.replace(" ", "").isalpha():
        return False

    return has_operator
def smart_split_args(arg_str):
    args = []
    current = ""
    in_string = False
    i = 0
    while i < len(arg_str):
        char = arg_str[i]
        if char == '"' and (i == 0 or arg_str[i-1] != '\\'):
            in_string = not in_string
            current += char
        elif char == ',' and not in_string:
            args.append(current.strip())
            current = ""
        else:
            current += char
        i += 1
    if current:
        args.append(current.strip())
    return args
def fetchdata(filea):
    global filel
    filel = filea
    with open(filea, "r") as file:
        return [line.strip() for line in file]
def tokenize_blocks(lines):
    blocks = []
    current_block = []
    depth = 0
    for line in lines:
        tokens = re.split(r'(\{|\})', line.strip())
        for token in tokens:
            token = token.strip()
            if not token:
                continue
            if token == '{':
                depth += 1
                current_block.append('{')
            elif token == '}':
                depth -= 1
                current_block.append('}')
                if depth == 0:
                    blocks.append(current_block)
                    current_block = []
            else:
                current_block.append(token)
    if current_block:
        blocks.append(current_block)
    return blocks
import re

def phrase_args(arg_str):
    args = []
    current = ''
    in_string = False
    quote_char = ''

    for i, ch in enumerate(arg_str):
        if ch in ['"', "'"]:
            if not in_string:
                in_string = True
                quote_char = ch
                current += ch
            elif in_string and ch == quote_char:
                in_string = False
                current += ch
            else:
                current += ch
        elif ch == ',' and not in_string:
            if current.strip():
                args.append(current.strip())
            current = ''
        else:
            current += ch

    if current.strip():
        args.append(current.strip())

    final_args = []
    for arg in args:
        if arg.startswith('"') and arg.endswith('"'):
            content = arg[1:-1]
            decoded = decode_flex_string(content)
            final_args.append(["string", decoded])
        elif arg.startswith("'") and arg.endswith("'"):
            content = arg[1:-1]
            decoded = decode_flex_string(content)
            final_args.append(["string", decoded])
        elif re.match(r'^[0-9]+$', arg):
            final_args.append(["int", int(arg)])
        elif re.match(r'^[0-9]+\.[0-9]+$', arg):
            final_args.append(["float", float(arg)])
        elif re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', arg):
            final_args.append(["varobject", arg])
        else:
            # Fallback as equation if none match
            final_args.append(["objectvar_equation", arg])

    return final_args


def parse_block(lines):
    block = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "" or line.startswith("#"):
            block.append(["unknown", ""])
            i += 1
            continue
        if line.startswith("class "):
            class_name = line.split()[1].strip(":")
            class_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                class_body.extend(sub_block)
                i += 1
            block.append(["class_def", class_name, class_body])
            continue
        if line.startswith("fnx "):
            parts = line[4:].split("(", 1)
            func_name = parts[0].strip()
            args = parts[1].split(")", 1)[0].strip()
            arg_list = [a.strip() for a in args.split(",") if a.strip()] if args else []

            # Skip to line with {
            while not "{" in line and i < len(lines):
                i += 1
                line = lines[i].strip()

            # Read function body block
            i += 1
            func_body_lines = []
            depth = 1  # already seen one {
            while i < len(lines):
                current_line = lines[i].strip()
                if "{" in current_line:
                    depth += current_line.count("{")
                if "}" in current_line:
                    depth -= current_line.count("}")
                if depth == 0:
                    break
                func_body_lines.append(current_line)
                i += 1

            # Parse body
            parsed_body = parse_block(func_body_lines)
            block.append(["function_def", func_name, ["fn_var"] + arg_list, parsed_body])
            i += 1  # move past the closing }
            continue



        if line.startswith("if "):
            condition = line[3:].strip().rstrip(":").strip("()")
            if_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                if_body.extend(sub_block)
                i += 1
            block.append(["if", "equation", condition, if_body])
            continue
        if line.startswith("else"):
            else_body = []
            i += 1
            while i < len(lines) and lines[i].startswith("    "):
                sub_block = parse_block([line[4:] for line in lines[i:i+1]])
                else_body.extend(sub_block)
                i += 1
            block.append(["block", else_body])
            continue
        block.append(parse_line(line))
        i += 1
    return block
def parse_line(line):
    line = line.strip()
    if line == "":
        return ["unknown", ""]

    if line.startswith("import-"):
        return ["import", line.split('"')[1]]

    if line.startswith("class "):
        return ["class_start", line.split()[1].strip(":")]

    if line.startswith("fnx "):
        parts = line[4:].split("(")
        name = parts[0].strip()
        args = parts[1].rstrip("):").strip()
        arg_list = [a.strip() for a in args.split(",")] if args else []
        return ["function_start", name, ["fn_var"] + arg_list]

    if line.startswith("return "):
        expr = line[7:].strip().rstrip(";")
        if any(op in expr for op in "+-*/%^()"):
            return ["return", ["objectvar_equation", expr]]
        elif expr.isdigit():
            return ["return", ["int", int(expr)]]
        elif re.match(r'^\d+\.\d+$', expr):
            return ["return", ["float", float(expr)]]
        elif expr.startswith('"') and expr.endswith('"'):
            return ["return", ["string", expr.strip('"')]]
        else:
            return ["return", ["varobject", expr]]

    # Assignment with potential function reference or expression
    if "=" in line and not line.startswith("if") and not line.startswith("while") and not line.startswith("for"):
        name, val = line.split("=", 1)
        name = name.strip()
        val = val.strip().rstrip(";")

        # function reference assignment (e.g., a = greet();)
        if val.endswith(");") and "(" in val:
            fname = val[:val.find("(")].strip()
            return ["assign", name, ["function_ref", fname]]

        # expression assignment
        if any(op in val for op in "+-*/%^()"):
            return ["assign", name, ["objectvar_equation", val]]

        # literal assignment
        if val.isdigit():
            return ["assign", name, ["int", int(val)]]
        elif re.match(r'^\d+\.\d+$', val):
            return ["assign", name, ["float", float(val)]]
        elif val.startswith('"') and val.endswith('"'):
            return ["assign", name, ["string", val.strip('"')]]
        else:
            return ["assign", name, ["varobject", val]]

    if line.startswith("reg "):
        inside = line[4:].split(":")
        return ["register", inside[0].strip().strip('"'), int(inside[1])]

    if line.startswith("cell "):
        num, val = line[5:].split(":")
        return ["cell_assign", int(num.strip()), val.strip().strip('"')]

    if line.startswith("pointer("):
        return ["pointer_set", int(line[8:-2])]

    if line == "print(:/);":
        return ["cell_print"]

    if line.startswith("if "):
        condition = line[3:].strip().rstrip(":").strip("()")
        return ["if_start", "equation", condition]

    if line.startswith("else"):
        return ["else_start"]

    if line.startswith("lambda "):
        expr = line[7:].strip()
        return ["lambda", ["objectvar_equation", expr]]
    if line.startswith("ifx(") and "):" in line and " % " in line:
        condition = line[line.find("(")+1:line.find("):")].strip()
        remaining = line[line.find("):")+2:]
        then_part, else_part = remaining.split(" % ", 1)

        then_node = parse_line(then_part.strip())
        else_node = parse_line(else_part.strip())

        return ["ifx", condition, then_node, else_node]
    if line.startswith("forx(") and "):" in line and ":" in line:
        header = line[line.find("(")+1:line.find("):")].strip()
        action_code = line[line.find("):")+2:].strip()

        init, cond, update = [x.strip() for x in header.split(";")]
        init_node = parse_line(init)  # This becomes assign node

        action_node = parse_line(action_code)

        return ["forx", init_node, cond, update, action_node]



    # Function call handling (support nested calls)
    if "(" in line and line.endswith(");"):
        name = line.split("(", 1)[0].strip()
        args_str = line[line.find("(")+1:line.rfind(")")].strip()

        def parse_args_nested(s):
            args = []
            current = ""
            depth = 0
            for ch in s:
                if ch == ',' and depth == 0:
                    args.append(current.strip())
                    current = ""
                else:
                    if ch == '(': depth += 1
                    elif ch == ')': depth -= 1
                    current += ch
            if current: args.append(current.strip())
            return args

        raw_args = parse_args_nested(args_str)
        arg_list = []

        for a in raw_args:
            a = a.strip()
            if "(" in a and a.endswith(")"):  # nested function call
                inner_line = a + ";"  # to satisfy parse_line
                parsed = parse_line(inner_line)
                arg_list.append(parsed)
            elif any(op in a for op in "+-*/%^()"):
                arg_list.append(["objectvar_equation", a])
            elif a.isdigit():
                arg_list.append(["int", int(a)])
            elif re.match(r'^\d+\.\d+$', a):
                arg_list.append(["float", float(a)])
            elif a.startswith('"') and a.endswith('"'):
                arg_list.append(["string", a.strip('"')])
            else:
                arg_list.append(["varobject", a])

        return ["FunctionCall", name, arg_list]


    # Dot access (object.method(...);)
    if "." in line and "(" in line and line.endswith(");"):
        obj, rest = line.split(".", 1)
        method, args = rest[:-2].split("(", 1)
        arg_list = [a.strip() for a in args.split(",")] if args else []
        return ["dot_call", obj.strip(), method.strip(), [["varobject", a] for a in arg_list]]

    return ["unknown", line]

def ast_builder(lines):
    ast = []
    block_stack = []
    current_block = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.endswith("{"):
            current_block.append(line)
            block_stack.append("{")
            continue
        elif line == "}":
            current_block.append(line)
            if block_stack:
                block_stack.pop()
            if not block_stack:
                parsed = parse_block(current_block)
                if parsed:
                    ast.extend(parsed)
                current_block = []

            continue
        if block_stack:
            current_block.append(line)
        else:
            parsed_line = parse_line(line)
            if parsed_line:
                ast.append(parsed_line)
    if current_block:
        parsed = parse_block(current_block)
        if parsed:
            ast.extend(parsed)  # instead of ast.append(parsed)
    return ast
def extract_block(lines, start_index):
    block = []
    depth = 0
    i = start_index
    while i < len(lines):
        line = lines[i].strip()
        if '{' in line:
            depth += line.count('{')
        if '}' in line:
            depth -= line.count('}')
        block.append(line)
        if depth == 0:
            break
        i += 1
    return block, i
def execute(file):
    ast_tree = ast_builder(fetchdata(file))
    with open(filel + "AT", "w") as file:
        json.dump(ast_tree, file, indent=1)
def decode_tree(path):
    with open(path, "r") as file:
        return json.load(file)