from core.evaluator import ArithmeticEvaluator
from core.astext import decode_flex_string
class Runner:
    variables = {}
    functions = {}
    return_value = None

    @staticmethod
    def is_valid_literal(value):
        if isinstance(value, (int, float, bool)):
            return True
        if isinstance(value, str):
            return value.startswith('"') and value.endswith('"')
        if isinstance(value, list):
            return True
        return False

    @staticmethod
    def run_tree(tree):
        for node in tree:
            Runner.run_node(node)

    @staticmethod
    def run_node(node):
        if not isinstance(node, list) or len(node) == 0:
            return

        node_type = node[0]

        # --- Function Definition ---
        if node_type == "function_def":
            func_name = node[1]
            arg_list = node[2][1:]  # remove "fn_var"
            body = node[3]
            Runner.functions[func_name] = {
                "args": arg_list,
                "body": body
            }

        # --- Function Reference Assignment ---
        elif node_type == "assign" and node[2][0] == "function_ref":
            var_name = node[1]
            func_name = node[2][1]
            Runner.variables[var_name] = Runner.functions.get(func_name)
        
        elif node_type == "ifx":
            condition_expr = node[1]
            then_stmt = node[2]
            else_stmt = node[3]
            cond_result = ArithmeticEvaluator().evaluate(condition_expr)[0]
            if cond_result:
                Runner.run_node(then_stmt)
            else:
                Runner.run_node(else_stmt)

        elif node_type == "forx":
            init_node = node[1]
            condition_expr = node[2]
            update_expr = node[3]
            body_node = node[4]

            # Run initialization (like x = 0)
            Runner.run_node(init_node)

            # Loop condition check
            while ArithmeticEvaluator().evaluate(condition_expr)[0]:
                Runner.run_node(body_node)
                
                # Handle increment expression: x++ or x = x + 1
                if "++" in update_expr:
                    var = update_expr.replace("++", "").strip()
                    Runner.variables[var] += 1
                elif "+=" in update_expr or "=" in update_expr:
                    # Convert to normal assign and run
                    var_name, value_expr = update_expr.split('=')
                    Runner.run_node(["assign", var_name.strip(), ["objectvar_equation", value_expr.strip()]])



        # --- Function Call (Built-in + User) ---
        elif node_type == "FunctionCall":
            func_name = node[1]
            args = node[2]

            # Handle function reference
            if func_name in Runner.variables and isinstance(Runner.variables[func_name], dict):
                func = Runner.variables[func_name]
            elif func_name in Runner.functions:
                func = Runner.functions[func_name]
            else:
                func = None

            if func_name == "print" or func_name == "println":
                output = []
                newline = func_name == "println"
                for arg in args:
                    val = Runner.evaluate_arg(arg)
                    # Decode special-encoded characters for string values
                    if isinstance(arg, list) and arg[0] == "string":
                        val = decode_flex_string(val)
                    output.append(val)
                print(*output, sep='', end='\n' if newline else '')
                return

            elif func_name == "input":
                if len(args) == 1 and args[0][0] == "varobject":
                    varname = args[0][1]
                    Runner.variables[varname] = input()
                else:
                    print("[Error: input() expects one variable argument]")
                return

            # --- User-defined or referenced function ---
            if func:
                arg_values = [Runner.evaluate_arg(a) for a in args]
                if len(arg_values) != len(func["args"]):
                    print(f"Error: Argument count mismatch for function '{func_name}'")
                    return

                backup_vars = Runner.variables.copy()
                Runner.variables.update(dict(zip(func["args"], arg_values)))

                return_value = None
                for stmt in func["body"]:
                    result = Runner.run_node(stmt)
                    if isinstance(result, dict) and "__return__" in result:
                        return_value = result["__return__"]
                        break

                Runner.variables = backup_vars
                return return_value

            print(f"Error: Unknown function '{func_name}'")

        # --- Variable Assignment ---
        elif node_type == "assign":
            var_name = node[1]
            value_node = node[2]

            if value_node[0] == "varobject":
                val = value_node[1]
                if val in Runner.variables:
                    Runner.variables[var_name] = Runner.variables[val]
                else:
                    try:
                        Runner.variables[var_name] = eval(val)
                    except:
                        print(f"Error: Invalid value '{val}'")
            elif value_node[0] == "objectvar_equation":
                try:
                    result = ArithmeticEvaluator().evaluate(value_node[1])[0]
                    Runner.variables[var_name] = result
                except Exception as e:
                    print(f"Error evaluating equation: {e}")
            else:
                Runner.variables[var_name] = value_node[1]

        # --- Return Statement ---
        elif node_type == "return":
            val = Runner.evaluate_arg(node[1])
            return {"__return__": val}

        # --- Unknown or comment ---
        elif node_type == "unknown":
            return

        else:
            print(f"Error: Unknown node type '{node_type}'")


    @staticmethod
    def evaluate_arg(arg):
        if isinstance(arg, list):
            if arg[0] == "FunctionCall":
                return Runner.run_node(arg)  # support nested call
            elif arg[0] == "objectvar_equation":
                try:
                    return ArithmeticEvaluator().evaluate(arg[1])[0]
                except Exception as e:
                    print(f"[Evaluation Failed for: {arg[1]}]")
                    raise e

            elif arg[0] == "varobject":
                return Runner.variables.get(arg[1], f"[Undefined var: {arg[1]}]")
            elif arg[0] in ("int", "float", "string"):
                return arg[1]
        return f"[Unsupported arg: {arg}]"
