# FLEX 1
FLEX 1 is a genral-purpose language Made by Aarav Singh Latwal

Our Mission is to make this language as a Language that is Multi-Purpose, like python is used for A.I.(Atrifical Intelligence) and Data Science but you can't make OS with python and assmbly

**it also have a benifit to have FLEX ECOSYSTEM**

**AND BROUGHT MILLIONS OF CHANGES TO THE WORLD**

so we are launching our first version of FLEX, this only have basic things but later new things will be added, don't be upset that it don't have. but it will come soon, new update every week. a Promise!

be exited because we are revaliing our planner(planner.txt)

## Running Guide
run ./flex.sh to run

available flags:
```
-r  --repl              Opens REPL
-v  --version           Tell the version 
[FILE]                  compiles the file (.flex) to ast tree (.flexAT) (not real compiler, comming )
-s  [FILE]              Runs the file
-l  --learn             learn FLEX
-h  --help              show help menu
-cu -checkforupdate     check for update
```

### **To Run .flex code, follow these**
1. [```./flex.sh app.flex```] Compile your Source Code to AST Tree
2. [```./flex.sh -s app.flexAT```] Runs the Source Code

# **LEARN FLEX 1...**
**Basic Rules:**

1. ADD ; at last of every statement

**** 
**Input/Output**

```print();``` : To Output the text given

```println();``` : to Output the text given but update line

```input();``` : it Ask for an input, and stores it in the variable given

```x = 0;``` : to assigen variable

```
fnx function(a, b) {
  print("function is called");
  return a*b-a+b;
} 

``` 
: to make a function and call it as ```function(5, 10);```

there are one liner if and loop but in FLEX 2 multi-line if and loop will come!

```ifx(x=0):function(); % ifnottrue();```: Single Lined IF Statement

```forx(x=0;x>10;x++):function();```: Single Lined FOR Statement

# Examples 
**Examples are given in example/**