#!/bin/bash

#~/Modules
#~/core/astext.py
#~/core/evalautor.py
#~/core/error.py
#~/core/runner.py
#~/flex.sh
#~/learn.html
#~/main.py
#~/planner.txt
#~/main.py
#~/repl.py
#~/readme.md 
#~/test.flex
#~/test.flexAbstractTree
#~/checks.py
#~/Tests/performence.png
#~/Tests/Range.png
#~/Tests/Possiblemarketgrowth.png
#~/Tests/Flexibility.png


python3 main.py "$@"
